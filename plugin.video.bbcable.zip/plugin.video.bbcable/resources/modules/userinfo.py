import base64

addon_name   = base64.b64decode('QitCIENhYmxlIEFsdGVybmF0aXZlcw==')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLmJiY2FibGU=')

host         = base64.b64decode('aHR0cDovL29rMi5zZQ==')
port         = base64.b64decode('ODAwMA==')