# -*- coding: utf-8 -*-


def debridDict():
    return {
    'realdebrid': [],
    'premiumize': [],
    'alldebrid': [],
    'rpnet': []
    }


def status():
    return False


def resolver(url, debrid):
    return


