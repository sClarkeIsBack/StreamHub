import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnN0cmVhbWh1YnA=')

name = b.b64decode('W0NPTE9SIGZmZmYwMDAwXVtCXVN0cmVhbUh1YlsvQ09MT1JdW0NPTE9SIGdvbGRdIFByZW1pdW1bL0NPTE9SXVsvQl0=')

host = b.b64decode('aHR0cDovL3N0cmVhbWh1YnByZW1pdW0uY28udWs=')

port = b.b64decode('ODA=')